using flesh_farming.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace flesh_farming
{
	public class Startup
	{
		public Startup(IConfiguration configuration)
		{
			Configuration = configuration;
		}

		public IConfiguration Configuration { get; }

		// This method gets called by the runtime. Use this method to add services to the container.
		public void ConfigureServices(IServiceCollection services)
		{
			// the DB service
			services.AddDbContext<AppDbContext>(options =>
			options.UseSqlServer(Configuration.GetConnectionString
			("DefaultConnection")));

            //// add identity consumption with users at startup
            //services.AddDefaultIdentity<IdentityUser>().AddEntityFrameworkStores<AppDbContext>();

            services.AddControllersWithViews();

            services.AddSession();
            services.AddRazorPages(); // identity

			// identity
			services.AddDefaultIdentity<IdentityUser>(options => options.SignIn.RequireConfirmedAccount = false)
				.AddRoles<IdentityRole>()
				.AddEntityFrameworkStores<AppDbContext>();
        }

		// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
		public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
		{
			if (env.IsDevelopment())
			{
				app.UseDeveloperExceptionPage();
			}
			else
			{
				app.UseExceptionHandler("/Home/Error");
				// The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
				app.UseHsts();
			}
			app.UseHttpsRedirection();
			app.UseStaticFiles();

			app.UseRouting();

			// needed
			app.UseAuthentication();

			app.UseAuthorization();

			app.UseEndpoints(async endpoints =>
			{
				endpoints.MapControllerRoute(
					name: "default",
					pattern: "{controller=Home}/{action=Index}/{id?}");

				// make register and login links work
                endpoints.MapRazorPages();

				// seeding some inital data into our system
				using (var scope = app.ApplicationServices.CreateScope())
				{
					// create roleManager, scope is used to access services
					var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();

					// create array that stores roles
					var roles = new[] { "Admin", "Employee", "User" };

					foreach (var role in roles)
					{
						// checks if roles are already added to system so there are no duplicates
						// if there are no roles, create the roles
						if (!await roleManager.RoleExistsAsync(role))
							await roleManager.CreateAsync(new IdentityRole(role));

					}

				}

				// seeding admin (SUPER USER)
				using (var scope = app.ApplicationServices.CreateScope())
				{
					// create userManager, scope is used to access services
					var userManager =
					scope.ServiceProvider.GetRequiredService<UserManager<IdentityUser>>();

					string email = "admin@admin.com";
					string password = "Test1234,";

					if (await userManager.FindByEmailAsync(email) == null)
					{
						var user = new IdentityUser();
						user.UserName = email;
						user.Email = email;

						await userManager.CreateAsync(user, password);

						// add user to role
						await userManager.AddToRoleAsync(user, "Admin");
					}
				}

				// seeding employee
                using (var scope = app.ApplicationServices.CreateScope())
                {
                    // create userManager, scope is used to access services
                    var userManager =
                    scope.ServiceProvider.GetRequiredService<UserManager<IdentityUser>>();

                    string email = "employee@employee.com";
                    string password = "Employee123,";

                    if (await userManager.FindByEmailAsync(email) == null)
                    {
                        var user = new IdentityUser();
                        user.UserName = email;
                        user.Email = email;

                        await userManager.CreateAsync(user, password);

                        // add user to role
                        await userManager.AddToRoleAsync(user, "Employee");
                    }
                }

                // seeding famer 1
                using (var scope = app.ApplicationServices.CreateScope())
                {
                    // create userManager, scope is used to access services
                    var userManager =
                    scope.ServiceProvider.GetRequiredService<UserManager<IdentityUser>>();

                    string email = "farmer1@farmer.com";
                    string password = "Farmer123,";

                    if (await userManager.FindByEmailAsync(email) == null)
                    {
                        var user = new IdentityUser();
                        user.UserName = email;
                        user.Email = email;

                        await userManager.CreateAsync(user, password);

                        // add user to role
                        await userManager.AddToRoleAsync(user, "User");
                    }
                }

                // seeding famer 2
                using (var scope = app.ApplicationServices.CreateScope())
                {
                    // create userManager, scope is used to access services
                    var userManager =
                    scope.ServiceProvider.GetRequiredService<UserManager<IdentityUser>>();

                    string email = "farmer2@farmer.com";
                    string password = "Farmer123,";

                    if (await userManager.FindByEmailAsync(email) == null)
                    {
                        var user = new IdentityUser();
                        user.UserName = email;
                        user.Email = email;

                        await userManager.CreateAsync(user, password);

                        // add user to role
                        await userManager.AddToRoleAsync(user, "User");
                    }
                }

            });
		}
	}
}
