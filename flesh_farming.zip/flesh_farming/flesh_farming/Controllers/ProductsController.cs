﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using flesh_farming.Models;
using System.Data;

namespace flesh_farming.Controllers
{
    public class ProductsController : Controller
    {
        private readonly AppDbContext _context;

        public ProductsController(AppDbContext context)
        {
            _context = context;
        }

        // created view for Employee to view list of Products;
        // takes two parameters for two functions:
        // 1. searchFarmer for filtering Products by a specific farmer that the Employee seaches for
        // 2. sortOrder for filtering Products by Product Type in ascending or descending order
        public async Task<IActionResult> ProductFilter(string searchFarmer, string sortOrder)
        {
            // sort category
            ViewBag.CategorySortParam = String.IsNullOrEmpty(sortOrder) ? "categoryName_desc" : "";

            var appDbContext = from b in _context.Products.Include(p => p.Category).Include(p => p.Farmer)
                               select b;

            // checks if user wants to search for Products by specific Farmer
            if (!String.IsNullOrEmpty(searchFarmer))
            {
                // checks for farmers with the name that matches the search by Emplployee
                appDbContext = appDbContext.Where(b => b.Farmer.farmerName.Contains(searchFarmer));
                
            }

            // sorting logic for filtering by Product Type
            switch (sortOrder)
            {
                case "categoryName_desc":
                    appDbContext = appDbContext.OrderByDescending(b => b.Category.categoryName);
                    break;
                default:
                    appDbContext = appDbContext.OrderBy(b => b.Category.categoryName);
                    break;
            }

            return View(await appDbContext.ToListAsync());
        }



        // GET: Products
        public async Task<IActionResult> Index()
        {
            var appDbContext = _context.Products.Include(p => p.Category).Include(p => p.Farmer);
            return View(await appDbContext.ToListAsync());
        }

        // GET: Products/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await _context.Products
                .Include(p => p.Category)
                .Include(p => p.Farmer)
                .FirstOrDefaultAsync(m => m.productId == id);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // GET: Products/Create
        public IActionResult Create()
        {
            ViewData["categoryId"] = new SelectList(_context.Categories, "categoryId", "categoryId");
            ViewData["farmerId"] = new SelectList(_context.Farmers, "farmerId", "farmerId");
            return View();
        }

        // POST: Products/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("productId,productName,productPrice,productImage,productDate,productIsInStock,productIsOnSale,categoryId,farmerId")] Product product)
        {
            if (ModelState.IsValid)
            {
                _context.Add(product);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["categoryId"] = new SelectList(_context.Categories, "categoryId", "categoryId", product.categoryId);
            ViewData["farmerId"] = new SelectList(_context.Farmers, "farmerId", "farmerId", product.farmerId);
            return View(product);
        }

        // GET: Products/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            ViewData["categoryId"] = new SelectList(_context.Categories, "categoryId", "categoryId", product.categoryId);
            ViewData["farmerId"] = new SelectList(_context.Farmers, "farmerId", "farmerId", product.farmerId);
            return View(product);
        }

        // POST: Products/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("productId,productName,productPrice,productImage,productDate,productIsInStock,productIsOnSale,categoryId,farmerId")] Product product)
        {
            if (id != product.productId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(product);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProductExists(product.productId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["categoryId"] = new SelectList(_context.Categories, "categoryId", "categoryId", product.categoryId);
            ViewData["farmerId"] = new SelectList(_context.Farmers, "farmerId", "farmerId", product.farmerId);
            return View(product);
        }

        // GET: Products/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await _context.Products
                .Include(p => p.Category)
                .Include(p => p.Farmer)
                .FirstOrDefaultAsync(m => m.productId == id);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // POST: Products/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var product = await _context.Products.FindAsync(id);
            _context.Products.Remove(product);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ProductExists(int id)
        {
            return _context.Products.Any(e => e.productId == id);
        }
    }
}
