﻿namespace flesh_farming.Models
{
    public class Farmer
    {
        public int farmerId { get; set; }
        public string farmerName { get; set; }
        public string farmerAddress { get; set; }
    }
}
