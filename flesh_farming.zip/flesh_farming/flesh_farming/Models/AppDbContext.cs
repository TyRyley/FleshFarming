﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Runtime.Serialization;

namespace flesh_farming.Models
{
	public class AppDbContext : IdentityDbContext<IdentityUser>
	{
        // this class is the bridge between the code and the database
		public AppDbContext(DbContextOptions<AppDbContext> options) :
		   // parse options to the DB
		   base(options)
		{
		}

        // DB set names --> what sets do you want to create
        public DbSet<Farmer> Farmers { get; set; }
        public DbSet<Product> Products { get; set; }
		public DbSet<Category> Categories { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            // seed the database

            // seed farmers
            builder.Entity<Farmer>().HasData(new Farmer { farmerId = 1, farmerName = "Elsie", farmerAddress = "3 Cow County, Cattleland" },
                                             new Farmer { farmerId = 2, farmerName = "Babe", farmerAddress = "16 Pork Place, Pinefield" });
              //  new Farmer { farmerId = 3, farmerName = "Donald", farmerAddress = "4 Duck Den, Denver" });

            builder.Entity<Category>().HasData(
                new Category { categoryId = 1, categoryName = "Beef" },
                new Category { categoryId = 2, categoryName = "Pork" },
                new Category { categoryId = 3, categoryName = "Chicken" },
                new Category { categoryId = 4, categoryName = "Lamb" },
                new Category { categoryId = 5, categoryName = "Veal" },  // comes from young calves
                new Category { categoryId = 6, categoryName = "Venison" },  // Dear meat
                new Category { categoryId = 7, categoryName = "Turkey" },
                new Category { categoryId = 8, categoryName = "Duck" },
                new Category { categoryId = 9, categoryName = "Fish " },
                new Category { categoryId = 10, categoryName = "Seafood" });

            // seed products
            builder.Entity<Product>().HasData(
                 new Product
                 {
                     productId = 1,
                     productName = "Sirloin Steak",
                     productPrice = 100M,
                     productImage = "~/images/sirloin.jpg",
                     productDate = DateTime.Parse("2023-01-01"),
                     productIsInStock = true,
                     productIsOnSale = false,
                     categoryId = 1,
                     farmerId = 1
                 });

            builder.Entity<Product>().HasData(
                 new Product
                 {
                     productId = 2,
                     productName = "Pork Chops",
                     productPrice = 100M,
                     productImage = "~/images/porkchops.jpg",
                     productDate = DateTime.Parse("2023-02-10"),
                     productIsInStock = true,
                     productIsOnSale = true,
                     categoryId = 2,
                     farmerId = 1
                 });

            builder.Entity<Product>().HasData(
                 new Product
                 {
                     productId = 3,
                     productName = "Chicken Nuggets",
                     productPrice = 70M,
                     productImage = "~/images/chickennuggets.jpeg",
                     productDate = DateTime.Parse("2023-03-20"),
                     productIsInStock = true,
                     productIsOnSale = false,
                     categoryId = 3,
                     farmerId = 2
                 });

            builder.Entity<Product>().HasData(
                 new Product
                 {
                     productId = 4,
                     productName = "Turkey Ham",
                     productPrice = 300M,
                     productImage = "~/images/turkeyham.jpg",
                     productDate = DateTime.Parse("2023-04-15"),
                     productIsInStock = false,
                     productIsOnSale = false,
                     categoryId = 7,
                     farmerId = 2
                 });

        }

    }
}
