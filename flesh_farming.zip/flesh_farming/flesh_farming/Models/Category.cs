﻿namespace flesh_farming.Models
{
	public class Category
	{
		public int categoryId { get; set; }
        public string categoryName { get; set; }
    }
}
